


export const userlar =  [
  {
    id:1,
    name:'eshmat'
  },

  {
    id:2,
    name:'toshmat'
  },

  {
    id:3,
    name:'pulmat'
  },

  {
    id:4,
    name:'kalmat'
  },

  {
    id:5,
    name:'gishmat'
  },

  {
    id:6,
    name:'popkamat'
  },

  {
    id:7,
    name:'pirmat'
  },

  {
    id:8,
    name:'nurmat'
  },

  {
    id:9,
    name:'hormat'
  },


  {
    id:10,
    name:'bormat'
  },

  {
    id:11,
    name:'urmat'
  },
]

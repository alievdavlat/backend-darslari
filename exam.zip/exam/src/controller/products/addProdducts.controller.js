import { read, write } from "../../utils/FS.js";

export const addProductsController = (req, res) => {
  try {
    const { verifyId } = req;
    const { name, price , count } = req.body;
    const allusers = read("users.json");
    const foundedUser = allusers.find((user) => user.id == verifyId);
  
    if (!foundedUser) {
      res.status(400).send("bunday user mavjud emas");
      return;
    }

    if (!name && !price && !count) {
      res.status(400).send({
        status: 400,
        data: null,
        msg: "ma'lumotlar xato kiritildi"
      });
      return
    }

    if (foundedUser.role === "admin") {
      const allProducts = read("products.json");
      const foundedProducts = allProducts.find(
        (product) => product.name == name
      );
      if (!foundedProducts) {
        allProducts.push({
          id: allProducts.at(-1)?.id + 1 || 1,
          name,
          price,
          count,
        });

        write("products.json", allProducts);
        res.status(201).send({
          status: 201,
          data: {
            id: allProducts.at(-1)?.id,
            name,
            price,
            count,
          },
          msg: "CREATED",
        });
        return;
      }

      foundedProducts.price = price;
      foundedProducts.count = foundedProducts.count + count;
      write("products.json", allProducts);
      res.status(201).send({
        status: 201,
        data: {
          id: foundedProducts.id,
          name,
          price: foundedProducts.price,
          count: foundedProducts.count,
        },
        msg: "CREATED",
      });
      return;
    }

    res.send("productni faqat admin qosholadi");
  } catch (error) {
    res.sendStatus(500);
  }
};

import { read, write } from "../../utils/FS.js";

export const accountFillingController = (req, res) => {
  
  try {
    const { verifyId } = req;
    const { id } = req.params;
    const { total } = req.body;
    const allUsers = read("users.json");


    const foundedUser = allUsers.find((user) => user.id == verifyId);

    if (verifyId == id) {
      res.send('ozini xisobni  toldr')
      return
  }

    if (!foundedUser) {
      res.status(404).send({
        status: 404,
        data: null,
        msg: "user hisob raqami topilmadi",
      });
    }

   

    if(typeof total == 'string' || typeof total == undefined || typeof total == NaN || typeof total == null){
     res.send('hisob toldirish uchun raqam yozing ')
    } else{
      foundedUser.account = foundedUser.account
      ? foundedUser.account + total
      : total
    }


    write("users.json", allUsers);

    res.status(200).send({
      status: 200,
      data: {
        username: foundedUser.username,
        account:foundedUser.account,
      },
      msg: "OK",
    });

  } catch (error) {
    res.sendStatus(500);
  }
};

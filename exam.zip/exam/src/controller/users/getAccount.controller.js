import { read } from "../../utils/FS.js";

export const getAccountController = (req, res) => {
  try {
    const { verifyId } = req;
      
    const allusers = read("users.json");
    
    const foundedUser = allusers.find((user) => user.id == verifyId);

    if (!foundedUser) {
      res.status(404).send({
        status: 404,
        data: null,
        msg: "user hisob raqami topilmadi",
      });
      return
    }

    res.status(200).json({
      status: 200,
      data: {
        username: foundedUser.username,
        account: foundedUser.account || "hisob bo'sh",
      },
      msg: "OK",
    });
  } catch (error) {
    res.sendStatus(500);
  }
};

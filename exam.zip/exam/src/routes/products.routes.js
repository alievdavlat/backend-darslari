import { Router } from "express";
import { addProductsController } from "../controller/products/addProdducts.controller.js";
import { getAllProductsController } from "../controller/products/getAllProducts.controller.js";
import { buyProductsMiddleware } from "../middlewares/buyProduct.middleware.js";
import { buyProductsController } from "../controller/products/buyProducts.controller.js";


export const productsRouter = Router()

productsRouter
    .post('/products', addProductsController)
    .post('/products/:id/buy', buyProductsMiddleware, buyProductsController)
    .get('/products', getAllProductsController)





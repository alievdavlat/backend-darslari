
import { Router } from "express";
import { getAccountController } from "../controller/users/getAccount.controller.js";
import { accountFillingController } from "../controller/users/fillingAccount.controller.js";


export const userRouter = Router()


  userRouter
      .get('/user/:account', getAccountController)
      .put('/user/:id/account', accountFillingController)